# simple_pomodoro
Aplicativo simples para gerenciamento de tempo. 

Criada pelo italiano Francesco Cirillo no final da década de 1980, a Pomodoro Technique ou Técnica Pomodoro consiste em uma metodologia de gerenciamento de tempo que encoraja as pessoas a trabalhar com o tempo que elas têm – e não contra ele.

Para isso, um cronômetro é utilizado para dividir seu dia de trabalho em períodos de 25 minutos de foco que posteriormente iniciam com intervalos de cinco minutos. Além disso, a cada quatro intervalos da divisão do tempo de 25 minutos, deve ser realizada uma pausa maior de 20 a 30 minutos.

https://pt.wikipedia.org/wiki/T%C3%A9cnica_pomodoro
